This sample project exhibits an animated sprite with data pulled from an external module, objects animated with an "enterFrame" runtime listener, and a container which visually constrains (clips) the scene objects inside a defined region.

RELATED GUIDES
[Sprite Animation](https://docs.coronalabs.com/guide/media/spriteAnimation/index.html)
[Using Containers (Clipped Groups)](https://docs.coronalabs.com/guide/graphics/container.html)
